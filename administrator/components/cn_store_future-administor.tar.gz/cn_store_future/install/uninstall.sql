DROP TABLE IF EXISTS `#__tz_portfolio_xref`,
 `#__tz_portfolio_fields_group`
,`#__tz_portfolio_fields`
, `#__tz_portfolio_categories`
,`#__tz_portfolio`
,`#__tz_portfolio_xref_content`
,`#__tz_portfolio_tags`
,`#__tz_portfolio_tags_xref`
,`#__tz_portfolio_users`,`#__tz_portfolio_plugin`;
